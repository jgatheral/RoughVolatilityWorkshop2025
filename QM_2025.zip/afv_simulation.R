#####################################################################################
# Jim Gatheral, June 2021
#
# A couple of bugs fixed by Ben Wood in April 2022.
# LM scheme added in June 2023.
#
#####################################################################################

library(gsl)
source("gamma_kernel.R") # This code uses the gamma kernel

###########################################################################
# Code to implement $\psi^-$ and $\psi^+$ for the Andersen QE step
###########################################################################
psiM <- function(psi,ev,w){
  beta2 <- 2/psi-1+sqrt(2/psi)*sqrt(abs(2/psi-1)) # The abs fixes situations where psi > 2
  alpha <- ev/(1+beta2)
  vf <- alpha*(sqrt(abs(beta2))+w)^2
  return(vf)
}

psiP <- function(psi,ev,u){
  p <- 2/(1+psi)
  gam <- ev/2*(1+psi)
  vf <- -(u<p)*gam*log(u/p)
  return(vf)
}

###########################################################################
# The Lileika-Mackevicius step
###########################################################################
psi.LM <- function(psi,U){ # varv and U are vectors of length(N)
  
  z <- psi
  A <- (3+sqrt(3))/4
  d <- sqrt((3+z*(A+3/4)^2)*z)
  
  x.1 <- 1+(A+3/4)*z-d
  x.2 <- 1+A*z
  x.3 <-1+(A+3/4)*z+d
  
  m.1 <- 1
  m.2 <- 1 + z
  m.3 <- 1 + 3*z + 3*z^2/2
  
  p.1 <- (m.3 - m.2 *(x.2+x.3) + m.1 * x.2 * x.3)/(x.1*(x.3-x.1)*(x.2-x.1))
  p.2 <- (-m.3 + m.2 *(x.1+x.3) - m.1 * x.1 * x.3)/(x.2*(x.3-x.2)*(x.2-x.1))
  p.3 <- (m.3 - m.2 *(x.1+x.2) + m.1 * x.1 * x.2)/(x.3*(x.3-x.2)*(x.3-x.1))
  
  res <- ifelse(U<p.1,x.1,ifelse(U<(p.2+p.1),x.2,x.3))
  return(res)
}

###########################################################################
# The Extended Lileika-Mackevicius step
###########################################################################
psi.LME <- function (U, k1, k2, al3, al4) 
  # Explicitly takes cumulants 
  # k3 = al3*k2hat^2;  k4 = al4*k2hat^3
{
  z <- k2/k1^2
  B <- al3 + sqrt(3/4*al3^2-al4/2)
  d <- sqrt((3 + z * B^2) * z)
  x.1 <- 1 + B * z - d
  x.2 <- 1 + (B - al3/2) * z
  x.3 <- 1 + B * z + d
  m.1 <- 1
  m.2 <- 1 + z
  m.3 <- 1 + 3 * z + al3 * z^2
  p.1 <- (m.3 - m.2 * (x.2 + x.3) + m.1 * x.2 * x.3)/(x.1 * 
                                                        (x.3 - x.1) * (x.2 - x.1))
  p.2 <- (-m.3 + m.2 * (x.1 + x.3) - m.1 * x.1 * x.3)/(x.2 * 
                                                         (x.3 - x.2) * (x.2 - x.1))
  p.3 <- (m.3 - m.2 * (x.1 + x.2) + m.1 * x.1 * x.2)/(x.3 * 
                                                        (x.3 - x.2) * (x.3 - x.1))
  res <- ifelse(U < p.1, x.1, ifelse(U < (p.2 + p.1), x.2, 
                                     x.3))
  return(res)
}

###########################################################################
# Version adapted for parallel computation
###########################################################################
RSQE.sim <- function (params, xi)
  function(paths, steps, expiries, output = "all") {
    
    library(gsl)
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    eps.0 <- 1e-10
    W <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    Wperp <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    sim <- function(expiry) {
      dt <- expiry/steps
      sqrt.dt <- sqrt(dt)
      tj <- (1:steps) * dt
      xij <- xi(tj)
      G00del <- G00(params)(dt)
      G00j <- c(0, G00p(tj))
      bstar <- sqrt(diff(G00j)/dt)
      bstar1 <- bstar[1] # bstar is average g over an interval
      u <- array(0, dim = c(steps, paths))
      v <- rep(xi(0), paths)
      xihat <- rep(xij[1], paths)
      x <- numeric(paths)
      y <- numeric(paths)
      w <- numeric(paths)
      for (j in 1:steps) {
        varv <- eta^2 * (xihat + 2 * H * v)/(1+2*H)* G00del
        psi <- varv/xihat^2
        vf <- ifelse(psi < 3/2, psiM(psi, xihat, W[j, ]), 
                     psiP(psi, xihat, U[j, ]))
        u[j, ] <- vf - xihat
        dw <- (v + vf)/2 * dt
        w <- w + dw
        dy <- as.numeric(u[j, ])/(eta * bstar1)
        y <- y + dy
        x <- x - dw/2 + sqrt(dw) * as.numeric(rho2m1 * Wperp[j, 
                                                             ]) + rho * dy
        btilde <- rev(bstar[2:(j+1)])
        if (j < steps) {
          xihat <- xij[j + 1] + as.numeric(btilde %*% u[1:j, 
                                                        ])/bstar1
        }
        xihat <- ifelse(xihat > eps.0, xihat, eps.0)
        v <- vf
      }
      res.sim <- switch(output, v = v, x = x, 
                        y = y, w = w, all = list(v = v, x = x, y = y, w = w))
      return(res.sim)
    }
    if (output != "all") {
      sim.out <- t(sapply(expiries, sim))
    }
    else {
      sim.out <- sim(expiries)
    }
    return(sim.out)
  }

#################################################################
# Hybrid QE simulation
#################################################################
HQE.sim <- function (params, xi)
  function(paths, steps, expiries, output = "all") {
    
    library(gsl)
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    eps.0 <- 1e-10
    W <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    Wperp <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    Z <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    Uperp <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    sim <- function(expiry) {
      dt <- expiry/steps
      sqrt.dt <- sqrt(dt)
      tj <- (1:steps) * dt
      xij <- xi(tj)
      G0del <- eta*G0(params)(dt)
      G1del <- eta*G1(params)(dt)
      G00del <- eta^2*G00(params)(dt)
      G11del <- eta^2*G11(params)(dt)
      G01del <- eta^2*G01(params)(dt)
      G00j <- eta^2*c(0, G00p(tj))
      bstar <- sqrt(diff(G00j)/dt)
      bstar1 <- bstar[1] # bstar is average g over an interval
      rho.vchi <- G0del/sqrt(G00del*dt)
      beta.vchi <- G0del/dt
      
      u <- array(0, dim = c(steps, paths))
      chi <- array(0, dim = c(steps, paths))
      v <- rep(xi(0), paths)
      xihat <- rep(xij[1], paths)
      x <- numeric(paths)
      y <- numeric(paths)
      w <- numeric(paths)
      
      for (j in 1:steps) {
        
        xibar <- (xihat + 2 * H * v)/(1 + 2 * H)
        var.eps <- xibar * G00del*(1-rho.vchi^2)
        
        # Ben Wood bug fixes are in the two succeeding lines
        psi.chi <- 4 * G00del * rho.vchi^2*xibar/xihat^2
        psi.eps <- 4 * G00del * (1 - rho.vchi^2)*xibar/xihat^2
        
        z.chi <- ifelse(psi.chi < 3/2, psiM(psi.chi, xihat/2, W[j, ]), 
                        psiP(psi.chi, xihat/2, U[j, ]))
        
        z.eps <- ifelse(psi.eps < 3/2, psiM(psi.eps, xihat/2, Wperp[j, ]), 
                        psiP(psi.eps, xihat/2, Uperp[j, ]))
        
        chi[j,] <- (z.chi-xihat/2)/beta.vchi
        eps <- z.eps-xihat/2
        u[j,] <- beta.vchi*chi[j,]+eps
        vf <- xihat + u[j,]
        vf <- ifelse(vf > eps.0, vf, eps.0)
        dw <- (v + vf)/2 * dt
        w <- w + dw 
        y <- y + chi[j,]
        x <- x - dw/2 + sqrt(dw) * as.numeric(rho2m1 * Z[j, 
                                                         ]) + rho * chi[j,]
        btilde <- rev(bstar[2:(j+1)])
        if (j < steps) {
          xihat <- xij[j + 1] + as.numeric(btilde %*% chi[1:j,])
        }
        v <- vf
      }
      res.sim <- switch(output, v = v, x = x, y = y, w = w, 
                        all = list(v = v, x = x, y = y, w = w))
      return(res.sim)
    }
    if (output != "all") {
      sim.out <- t(sapply(expiries, sim))
    }
    else {
      sim.out <- sim(expiries)
    }
    return(sim.out)
  }



###########################################################################
# Riemann sum simulation with Lileika-Mackevicius step
###########################################################################
RSLM.sim <- function (params, xi) function(paths, steps, expiries, output = "all") {
    library(gsl)
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    eps.0 <- 1e-10
    Wperp <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    sim <- function(expiry) {
        dt <- expiry/steps
        sqrt.dt <- sqrt(dt)
        tj <- (1:steps) * dt
        xij <- xi(tj)
        G00del <- G00(params)(dt)
        G00j <- c(0, G00p(tj))
        bstar <- sqrt(diff(G00j)/dt)
        bstar1 <- bstar[1]
        u <- array(0, dim = c(steps, paths))
        v <- rep(xi(0), paths)
        xihat <- rep(xij[1], paths)
        x <- numeric(paths)
        y <- numeric(paths)
        w <- numeric(paths)
        for (j in 1:steps) {
            varv <- eta^2 * (xihat + 2 * H * v)/(1 + 2 * H) * 
                G00del
            psi <- varv/xihat^2
            vf <- psi.LM(psi,U[j,])*xihat
            u[j, ] <- vf - xihat
            dw <- (v + vf)/2 * dt
            w <- w + dw
            dy <- as.numeric(u[j, ])/(eta * bstar1)
            y <- y + dy
            x <- x - dw/2 + sqrt(dw) * as.numeric(rho2m1 * Wperp[j, 
                ]) + rho * dy
            btilde <- rev(bstar[2:(j + 1)])
            if (j < steps) {
                xihat <- xij[j + 1] + as.numeric(btilde %*% u[1:j, 
                  ])/bstar1
            }
            v <- vf
        }
        res.sim <- switch(output, v = v, x = x, y = y, w = w, 
            all = list(v = v, x = x, y = y, w = w))
        return(res.sim)
    }
    if (output != "all") {
        sim.out <- t(sapply(expiries, sim))
    }
    else {
        sim.out <- sim(expiries)
    }
    return(sim.out)
}

###########################################################################
# Hybrid simulation with Lileika-Mackevicius step
###########################################################################
HLM.sim <- function (params, xi) 
  function(paths, steps, expiries, output = "all") {
    library(gsl)
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    eps.0 <- 1e-10
    Z <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    Uperp <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    sim <- function(expiry) {
      dt <- expiry/steps
      sqrt.dt <- sqrt(dt)
      tj <- (1:steps) * dt
      xij <- xi(tj)
      G0del <- eta * G0(params)(dt)
      G00del <- eta^2 * G00(params)(dt)
      G00j <- eta^2 * c(0, G00p(tj))
      bstar <- sqrt(diff(G00j)/dt)
      bstar1 <- bstar[1]
      rho.vchi <- G0del/sqrt(G00del * dt)
      beta.vchi <- G0del/dt
      u <- array(0, dim = c(steps, paths))
      chi <- array(0, dim = c(steps, paths))
      v <- rep(xi(0), paths)
      xihat <- rep(xij[1], paths)
      x <- numeric(paths)
      y <- numeric(paths)
      w <- numeric(paths)
      for (j in 1:steps) {
        xibar <- (xihat + 2 * H * v)/(1 + 2 * H)
        var.eps <- xibar * G00del * (1 - rho.vchi^2)
        psi.chi <- 4 * G00del * rho.vchi^2 * xibar/xihat^2
        psi.eps <- 4 * G00del * (1 - rho.vchi^2) * xibar/xihat^2
        z.chi <- psi.LM(psi.chi,U[j,])*xihat/2
        #             print(head(z.chi))
        z.eps <- psi.LM(psi.eps,Uperp[j,])*xihat/2
        #                         print(head(z.eps))
        chi[j, ] <- (z.chi - xihat/2)/beta.vchi
        eps <- z.eps - xihat/2
        u[j, ] <- beta.vchi * chi[j, ] + eps
        vf <- xihat + u[j, ]
        #             vf <- ifelse(vf > eps.0, vf, eps.0)
        dw <- (v + vf)/2 * dt
        w <- w + dw
        y <- y + chi[j, ]
        x <- x - dw/2 + sqrt(dw) * as.numeric(rho2m1 * Z[j, 
        ]) + rho * chi[j, ]
        btilde <- rev(bstar[2:(j + 1)])
        if (j < steps) {
          xihat <- xij[j + 1] + as.numeric(btilde %*% chi[1:j, 
          ])
        }
        v <- vf
      }
      res.sim <- switch(output, v = v, x = x, y = y, w = w, 
                        all = list(v = v, x = x, y = y, w = w))
      return(res.sim)
    }
    if (output != "all") {
      sim.out <- t(sapply(expiries, sim))
    }
    else {
      sim.out <- sim(expiries)
    }
    return(sim.out)
  }


###########################################################################
# Riemann sum simulation with extended Lileika-Mackevicius step
###########################################################################
RSLME.sim <- function (params, xi) 
  function(paths, steps, expiries, output = "all") {
    library(gsl)
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    
    alH <- 3/2*gamma(2*H+1)*gamma(H+1/2)/gamma(3*H+1/2)
    beH <- gamma(2*H+1)*gamma(H+1/2)^2/gamma(3*H+1/2)*(
      2*gamma(4*H+1)/gamma(5*H+1/2)+gamma(2*H+1)/gamma(3*H+1/2))
    B <- alH + sqrt(3*alH^2/4-beH/2)
    
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    eps.0 <- 1e-10
    Wperp <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    sim <- function(expiry) {
      dt <- expiry/steps
      sqrt.dt <- sqrt(dt)
      tj <- (1:steps) * dt
      xij <- xi(tj)
      G00del <- G00(params)(dt)
      G00j <- c(0, G00p(tj))
      bstar <- sqrt(diff(G00j)/dt)
      bstar1 <- bstar[1]
      u <- array(0, dim = c(steps, paths))
      v <- rep(xi(0), paths)
      xihat <- rep(xij[1], paths)
      x <- numeric(paths)
      y <- numeric(paths)
      w <- numeric(paths)
      for (j in 1:steps) {
        varv <- eta^2 * (xihat + 2 * H * v)/(1 + 2 * H) * 
          G00del
        psi <- varv/xihat^2
        vf <- psi.LME(psi, U[j, ],B,alH) * xihat
        #             print(vf)
        u[j, ] <- vf - xihat
        dw <- (v + vf)/2 * dt
        w <- w + dw
        dy <- as.numeric(u[j, ])/(eta * bstar1)
        y <- y + dy
        x <- x - dw/2 + sqrt(dw) * as.numeric(rho2m1 * Wperp[j, 
        ]) + rho * dy
        btilde <- rev(bstar[2:(j + 1)])
        if (j < steps) {
          xihat <- xij[j + 1] + as.numeric(btilde %*% u[1:j, 
          ])/bstar1
        }
        v <- vf
      }
      res.sim <- switch(output, v = v, x = x, y = y, w = w, 
                        all = list(v = v, x = x, y = y, w = w))
      return(res.sim)
    }
    if (output != "all") {
      sim.out <- t(sapply(expiries, sim))
    }
    else {
      sim.out <- sim(expiries)
    }
    return(sim.out)
  }

###########################################################################
# Hybrid simulation with extended Lileika-Mackevicius step
###########################################################################
HLME.sim <- function (params, xi)function(paths, steps, expiries, output = "all") {
  library(gsl)
  
  eta <- params$eta
  lam <- params$lam
  H <- params$al - 1/2
  al3 <- 3/2 * gamma(2 * H + 1) * gamma(H + 1/2)/gamma(3 * 
                                                         H + 1/2)
  al4 <- gamma(2 * H + 1) * gamma(H + 1/2)^2/gamma(3 * H + 
                                                     1/2) * (2 * gamma(4 * H + 1)/gamma(5 * H + 1/2) + gamma(2 * 
                                                                                                               H + 1)/gamma(3 * H + 1/2))
  rho <- params$rho
  rho2m1 <- sqrt(1 - rho * rho)
  Z <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
  U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
  Uperp <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
  G00p <- Vectorize(G00(params))
  sim <- function(expiry) {
    dt <- expiry/steps
    sqrt.dt <- sqrt(dt)
    tj <- (1:steps) * dt
    xij <- xi(tj)
    G0del <- eta * G0(params)(dt)
    G00del <- eta^2 * G00(params)(dt)
    G00j <- eta^2 * c(0, G00p(tj))
    bstar <- sqrt(diff(G00j)/dt)
    bstar1 <- bstar[1]
    rho.vchi <- G0del/sqrt(G00del * dt)
    beta.vchi <- G0del/dt
    u <- array(0, dim = c(steps, paths))
    chi <- array(0, dim = c(steps, paths))
    v <- rep(xi(0), paths)
    xihat <- rep(xij[1], paths)
    x <- numeric(paths)
    y <- numeric(paths)
    w <- numeric(paths)
    
    for (j in 1:steps) {
      aH <- 2*H /(1 + 2 * H)
      #             vbar <- (v/xihat)^aH * xihat # New representation yet to be analyzed
      #             vbar <- 1 /(1 + 2 * H)*(2*H*v + xihat)
      vbar <- xihat
      psi <- vbar /xihat^2
      beta1sq <- psi * G0del^2/dt # Eqn (7.1)
      beta1 <- sqrt(beta1sq)
      beta2sq <- psi * G00del  - beta1sq # Eqn (7.1)
      beta2 <- sqrt(beta2sq)
      
      k1x <- 1/(beta1+beta2) # Mean of X1, X2.  Note that mean of Vhat is 1
      k2x <- 1 # We chose the Xi to have unit variance
      
      r <- rho.vchi
      rbar <- sqrt(1-r*r)
      al3.r <- al3  /((r+rbar) * (r^3 + rbar^3))# We'll fix this later...
      al4.r <- al4 /((r+rbar)^2 * (r^4 + rbar^4))
      
      x1 <- psi.LME(U[j, ],k1x,k2x,al3.r,al4.r) * k1x # psi.LME returns a rv with mean 1
      x2 <- psi.LME(Uperp[j, ],k1x,k2x,al3.r,al4.r) * k1x
      
      vf <- xihat * (beta1*x1 + beta2*x2)
      chi[j,] <- xihat * beta1 * (x1 - k1x) / beta.vchi
      dw <- (v + vf)/2 * dt
      y <- y + chi[j, ]
      x <- x - dw/2 + sqrt(dw) * as.numeric(rho2m1 * Z[j, 
      ]) + rho * chi[j, ]
      btilde <- rev(bstar[2:(j + 1)])
      if (j < steps) {
        xihat <- xij[j + 1] + as.numeric(btilde %*% chi[1:j, 
        ])
      }
      v <- vf
    }
    res.sim <- switch(output, v = v, x = x, y = y, w = w, 
                      all = list(v = v, x = x, y = y, w = w))
    return(res.sim)
  }
  if (output != "all") {
    sim.out <- t(sapply(expiries, sim))
  }
  else {
    sim.out <- sim(expiries)
  }
  return(sim.out)
}

###########################################################################
# Hybrid simulation with quadratic exponential (QE) step that generates 
# a matrix with vectors of y, v, and w.
#
# The output can be used for Romano-Touzi
###########################################################################
HQE.ywv <- function (params, xi) 
  function(paths, steps, expiries) {
    library(gsl)
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    eps.0 <- 1e-10
    W <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    Wperp <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    Uperp <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    nn <- length(expiries)
    res.matrix <- array(NA,dim=c(nn*3,paths))
    
    for (i in 1:nn) {
      expiry <- expiries[i]
      dt <- expiry/steps
      sqrt.dt <- sqrt(dt)
      tj <- (1:steps) * dt
      xij <- xi(tj)
      G0del <- eta * G0(params)(dt)
      G1del <- eta * G1(params)(dt)
      G00del <- eta^2 * G00(params)(dt)
      G11del <- eta^2 * G11(params)(dt)
      G01del <- eta^2 * G01(params)(dt)
      G00j <- eta^2 * c(0, G00p(tj))
      bstar <- sqrt(diff(G00j)/dt)
      bstar1 <- bstar[1]
      rho.vchi <- G0del/sqrt(G00del * dt)
      beta.vchi <- G0del/dt
      u <- array(0, dim = c(steps, paths))
      chi <- array(0, dim = c(steps, paths))
      v <- rep(xi(0), paths)
      xihat <- rep(xij[1], paths)
      y <- numeric(paths)
      w <- numeric(paths)
      for (j in 1:steps) {
        xibar <- (xihat + 2 * H * v)/(1 + 2 * H)
        # var.chi <- xibar * dt
        var.eps <- xibar * G00del * (1 - rho.vchi^2)
        # Ben Wood bug fixes are in the two succeeding lines
        psi.chi <- 4 * G00del * rho.vchi^2*xibar/xihat^2
        psi.eps <- 4 * G00del * (1 - rho.vchi^2)*xibar/xihat^2
        z.chi <- ifelse(psi.chi < 3/2, psiM(psi.chi, xihat/2, 
                                            W[j, ]), psiP(psi.chi, xihat/2, U[j, ]))
        z.eps <- ifelse(psi.eps < 3/2, psiM(psi.eps, xihat/2, 
                                            Wperp[j, ]), psiP(psi.eps, xihat/2, Uperp[j, 
                                            ]))
        chi[j, ] <- (z.chi - xihat/2)/beta.vchi
        eps <- z.eps - xihat/2
        u[j, ] <- beta.vchi * chi[j, ] + eps
        vf <- xihat + u[j, ]
        vf <- ifelse(vf > eps.0, vf, eps.0)
        dw <- (v + vf)/2 * dt
        w <- w + dw
        y <- y + chi[j, ]
        btilde <- rev(bstar[2:(j + 1)])
        if (j < steps) {
          xihat <- xij[j + 1] + as.numeric(btilde %*% chi[1:j, 
          ])
        }
        v <- vf
      }
      res.matrix[3*(i-1)+1,] <- y - mean(y)
      res.matrix[3*(i-1)+2,] <- w
      res.matrix[3*(i-1)+3,] <- v
    }
    return(res.matrix)
  }

###########################################################################
# Hybrid simulation with Lileika-Mackevicius step that generates 
# a matrix with vectors of y, v, and w.
#
# The output can be used for Romano-Touzi
###########################################################################

HLM.ywv <- function (params,xi) function(paths, steps, expiries) {
  
  library(gsl)
  
  N <- paths
  
  eta <- params$eta
  lam <- params$lam
  H <- params$al - 1/2
  rho <- params$rho
  rho2m1 <- sqrt(1 - rho * rho)
  
  Z <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
  U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
  Uperp <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
  G00p <- Vectorize(G00(params))
  
  K00p <- Vectorize(K00(params))
  
  yvw <- function(expiry) {
    
    dt <- expiry/steps
    sqrt.dt <- sqrt(dt)
    tj <- (1:steps) * dt
    xij <- xi(tj)
    G0del <- eta * G0(params)(dt)
    G00del <- eta^2 * G00(params)(dt)
    G00j <- eta^2 * c(0, G00p(tj))
    bstar <- sqrt(diff(G00j)/dt)
    bstar1 <- bstar[1]
    rho.vchi <- G0del/sqrt(G00del * dt)
    beta.vchi <- G0del/dt
    u <- array(0, dim = c(steps, paths))
    chi <- array(0, dim = c(steps, paths))
    v <- rep(xi(0), paths)
    xihat <- rep(xij[1], paths)
    x <- numeric(paths)
    y <- numeric(paths)
    w <- numeric(paths)
    
    for (j in 1:steps) {
      
      xibar <- (xihat + 2 * H * v)/(1 + 2 * H)
      var.eps <- xibar * G00del * (1 - rho.vchi^2)
      psi.chi <- 4 * G00del * rho.vchi^2 * xibar/xihat^2
      psi.eps <- 4 * G00del * (1 - rho.vchi^2) * xibar/xihat^2
      
      z.chi <- psi.LM(psi.chi,U[j,])*xihat/2
      z.eps <- psi.LM(psi.eps,Uperp[j,])*xihat/2
      chi[j, ] <- (z.chi - xihat/2)/beta.vchi
      eps <- z.eps - xihat/2
      u[j, ] <- beta.vchi * chi[j, ] + eps
      vf <- xihat + u[j, ]
      dw <- (v + vf)/2 * dt
      w <- w + dw
      y <- y + chi[j, ]
      x <- x - dw/2 + sqrt(dw) * as.numeric(rho2m1 * Z[j, ]) + rho * chi[j, ]
      btilde <- rev(bstar[2:(j + 1)])
      if (j < steps) {
        xihat <- xij[j + 1] + as.numeric(btilde %*% chi[1:j, 
        ])
      }
      v <- vf
    }
    yvw.res <- array(dim = c(3, N))
    yvw.res[1, ] <- y -mean(y)
    yvw.res[2, ] <- w
    yvw.res[3, ] <- v
    return(yvw.res)
  }
  n.exp <- length(expiries)
  yvwMatrix <- matrix(NA, nrow = 3 * n.exp, ncol = N)
  for (i in 1:n.exp) {
    yvwMatrix[(1:3) + 3 * (i - 1), ] <- yvw(expiries[i])
  }
  row.names(yvwMatrix) <- rep(c("y","w","v"),n.exp)
  return(yvwMatrix)
}

################################################

HLME.ywv <- function (params, xi) 
  function(paths, steps, expiries) {
    library(gsl)
    N <- paths
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    al3 <- 3/2 * gamma(2 * H + 1) * gamma(H + 1/2)/gamma(3 * 
                                                           H + 1/2)
    al4 <- gamma(2 * H + 1) * gamma(H + 1/2)^2/gamma(3 * H + 
                                                       1/2) * (2 * gamma(4 * H + 1)/gamma(5 * H + 1/2) + gamma(2 * 
                                                                                                                 H + 1)/gamma(3 * H + 1/2))
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    Z <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    Uperp <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    K00p <- Vectorize(K00(params))
    yvw <- function(expiry) {
      dt <- expiry/steps
      sqrt.dt <- sqrt(dt)
      tj <- (1:steps) * dt
      xij <- xi(tj)
      G0del <- eta * G0(params)(dt)
      G00del <- eta^2 * G00(params)(dt)
      G00j <- eta^2 * c(0, G00p(tj))
      bstar <- sqrt(diff(G00j)/dt)
      bstar1 <- bstar[1]
      rho.vchi <- G0del/sqrt(G00del * dt)
      beta.vchi <- G0del/dt
      u <- array(0, dim = c(steps, paths))
      chi <- array(0, dim = c(steps, paths))
      v <- rep(xi(0), paths)
      xihat <- rep(xij[1], paths)
      y <- numeric(paths)
      w <- numeric(paths)
      for (j in 1:steps) {
        aH <- 2 * H/(1 + 2 * H)
        vbar <- xihat
        psi <- vbar/xihat^2
        beta1sq <- psi * G0del^2/dt
        beta1 <- sqrt(beta1sq)
        beta2sq <- psi * G00del - beta1sq
        beta2 <- sqrt(beta2sq)
        k1x <- 1/(beta1 + beta2)
        k2x <- 1
        r <- rho.vchi
        rbar <- sqrt(1 - r * r)
        al3.r <- al3/((r + rbar) * (r^3 + rbar^3))
        al4.r <- al4/((r + rbar)^2 * (r^4 + rbar^4))
        x1 <- psi.LME(U[j, ], k1x, k2x, al3.r, al4.r) * k1x
        x2 <- psi.LME(Uperp[j, ], k1x, k2x, al3.r, al4.r) * 
          k1x
        vf <- xihat * (beta1 * x1 + beta2 * x2)
        chi[j, ] <- xihat * beta1 * (x1 - k1x)/beta.vchi
        dw <- (v + vf)/2 * dt
        w <- w + dw
        y <- y + chi[j, ]
        btilde <- rev(bstar[2:(j + 1)])
        if (j < steps) {
          xihat <- xij[j + 1] + as.numeric(btilde %*% chi[1:j, 
          ])
        }
        v <- vf
      }
      yvw.res <- array(dim = c(3, N))
      yvw.res[1, ] <- y - mean(y)
      yvw.res[2, ] <- w
      yvw.res[3, ] <- v
      return(yvw.res)
    }
    n.exp <- length(expiries)
    yvwMatrix <- matrix(NA, nrow = 3 * n.exp, ncol = N)
    for (i in 1:n.exp) {
      yvwMatrix[(1:3) + 3 * (i - 1), ] <- yvw(expiries[i])
    }
    row.names(yvwMatrix) <- rep(c("y", "w", "v"), n.exp)
    return(yvwMatrix)
  }

###########################################################################
# Blipped Hybrid simulation with quadratic exponential (QE) step that generates 
# a matrix with vectors of y, v, and w.
#
# The blip implements the finite difference computation of beta for SSR.
#
# The output can be used for Romano-Touzi
###########################################################################
HQE.ywv.h <- function (params, xi,h) 
  function(paths, steps, expiries) {
    library(gsl)
    eta <- params$eta
    lam <- params$lam
    H <- params$al - 1/2
    rho <- params$rho
    rho2m1 <- sqrt(1 - rho * rho)
    eps.0 <- 1e-10
    W <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    Wperp <- matrix(rnorm(steps * paths), nrow = steps, ncol = paths)
    U <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    Uperp <- matrix(runif(steps * paths), nrow = steps, ncol = paths)
    G00p <- Vectorize(G00(params))
    gp <- Vectorize(gGamma(params))
    nn <- length(expiries)
    res.matrix <- array(NA, dim = c(nn * 6, paths))
    
    
    xi.h <- function(s){xi(s)+h*rho*eta*gp(s)} # Blipped xi
    
    for (i in 1:nn) {
      expiry <- expiries[i]
      dt <- expiry/steps
      sqrt.dt <- sqrt(dt)
      tj <- (1:steps) * dt
      G0del <- eta * G0(params)(dt)
      G1del <- eta * G1(params)(dt)
      G00del <- eta^2 * G00(params)(dt)
      G11del <- eta^2 * G11(params)(dt)
      G01del <- eta^2 * G01(params)(dt)
      G00j <- eta^2 * c(0, G00p(tj))
      bstar <- sqrt(diff(G00j)/dt)
      bstar1 <- bstar[1]
      rho.vchi <- G0del/sqrt(G00del * dt)
      beta.vchi <- G0del/dt
      u <- array(0, dim = c(steps, paths))
      chi <- array(0, dim = c(steps, paths))
      
      xij <- xi(tj)
      chi <- array(0, dim = c(steps, paths))
      v <- rep(xi(0), paths)
      xihat <- rep(xij[1], paths)
      y <- numeric(paths)
      w <- numeric(paths)
      
      
      xij.h <- xi.h(tj)
      chi.h <- array(0, dim = c(steps, paths))
      xihat.h <- rep(xij.h[1], paths)
      v.h <- rep(xij[1], paths)
      y.h <- numeric(paths)
      w.h <- numeric(paths)
      
      for (j in 1:steps) {
        
        # Base case
        xibar <- (xihat + 2 * H * v)/(1 + 2 * H)
        var.eps <- xibar * G00del * (1 - rho.vchi^2)
        psi.chi <- 4 * G00del * rho.vchi^2 * xibar/xihat^2
        psi.eps <- 4 * G00del * (1 - rho.vchi^2) * xibar/xihat^2
        z.chi <- ifelse(psi.chi < 3/2, psiM(psi.chi, xihat/2, 
                                            W[j, ]), psiP(psi.chi, xihat/2, U[j, ]))
        z.eps <- ifelse(psi.eps < 3/2, psiM(psi.eps, xihat/2, 
                                            Wperp[j, ]), psiP(psi.eps, xihat/2, Uperp[j, 
                                            ]))
        chi[j, ] <- (z.chi - xihat/2)/beta.vchi
        eps <- z.eps - xihat/2
        u[j, ] <- beta.vchi * chi[j, ] + eps
        vf <- xihat + u[j, ]
        vf <- ifelse(vf > eps.0, vf, eps.0)
        dw <- (v + vf)/2 * dt
        w <- w + dw
        y <- y + chi[j, ]
        btilde <- rev(bstar[2:(j + 1)])
        if (j < steps) {
          xihat <- xij[j + 1] + as.numeric(btilde %*% chi[1:j, 
          ])
        }
        v <- vf
        
        
        # Blipped case
        
        xibar <- (xihat.h + 2 * H * v.h)/(1 + 2 * H)
        var.eps <- xibar * G00del * (1 - rho.vchi^2)
        psi.chi <- 4 * G00del * rho.vchi^2 * xibar/xihat.h^2
        psi.eps <- 4 * G00del * (1 - rho.vchi^2) * xibar/xihat.h^2
        z.chi <- ifelse(psi.chi < 3/2, psiM(psi.chi, xihat.h/2, 
                                            W[j, ]), psiP(psi.chi, xihat.h/2, U[j, ]))
        z.eps <- ifelse(psi.eps < 3/2, psiM(psi.eps, xihat.h/2, 
                                            Wperp[j, ]), psiP(psi.eps, xihat.h/2, Uperp[j, 
                                            ]))
        chi.h[j, ] <- (z.chi - xihat.h/2)/beta.vchi
        eps <- z.eps - xihat.h/2
        u[j, ] <- beta.vchi * chi.h[j, ] + eps
        vf.h <- xihat.h + u[j, ]
        vf.h <- ifelse(vf.h > eps.0, vf.h, eps.0)
        dw.h <- (v.h + vf.h)/2 * dt
        w.h <- w.h + dw.h
        y.h <- y.h + chi.h[j, ]
        btilde <- rev(bstar[2:(j + 1)])
        if (j < steps) {
          xihat.h <- xij.h[j + 1] + as.numeric(btilde %*% chi.h[1:j, 
          ])
        }
        v.h <- vf.h
      }
      
      res.matrix[6 * (i - 1) + 1, ] <- y
      res.matrix[6 * (i - 1) + 2, ] <- w
      res.matrix[6 * (i - 1) + 3, ] <- v
      res.matrix[6 * (i - 1) + 4, ] <- y.h
      res.matrix[6 * (i - 1) + 5, ] <- w.h
      res.matrix[6 * (i - 1) + 6, ] <- v.h
      
    }
    return(res.matrix)
  }